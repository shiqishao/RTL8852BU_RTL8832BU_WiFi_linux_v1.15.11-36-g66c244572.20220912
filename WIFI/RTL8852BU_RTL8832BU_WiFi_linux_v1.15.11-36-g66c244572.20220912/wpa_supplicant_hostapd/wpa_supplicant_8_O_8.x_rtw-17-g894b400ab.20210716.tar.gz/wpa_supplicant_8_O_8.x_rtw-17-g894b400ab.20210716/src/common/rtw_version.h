#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw-17-g894b400ab.20210716"
#endif /* RTW_VERSION_H */
